# Importing Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
dataset = pd.read_csv('C:\ML_Data_Sets\Restaurant_Reviews.tsv', delimiter='\t',quoting = 3)
print(dataset)

